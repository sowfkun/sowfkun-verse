document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('autofill-form');
  const btnSave = document.getElementById('btn-save');
  const btnTrigger = document.getElementById('btn-trigger');
  const statusMsg = document.getElementById('status-message');

  const fields = {
    fullname: document.getElementById('val-fullname'),
    phone: document.getElementById('val-phone'),
    email: document.getElementById('val-email'),
    identity: document.getElementById('val-identity'),
    address: document.getElementById('val-address'),
    yob: document.getElementById('val-yob')
  };

  // 1. Load saved data from chrome.storage.local
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(Object.keys(fields), (result) => {
      Object.keys(fields).forEach(key => {
        if (result[key]) {
          fields[key].value = result[key];
        }
      });
    });
  } else {
    // Local environment fallback for testing
    console.log('Running outside Chrome Extension context. Loading mockup data.');
    const mockData = JSON.parse(localStorage.getItem('autofill_mock') || '{}');
    Object.keys(fields).forEach(key => {
      if (mockData[key]) {
        fields[key].value = mockData[key];
      }
    });
  }

  // 2. Save data to storage on submit
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const dataToSave = {};
    Object.keys(fields).forEach(key => {
      dataToSave[key] = fields[key].value.trim();
    });

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set(dataToSave, () => {
        showStatus('💾 Đã lưu thông tin thành công!', true);
      });
    } else {
      localStorage.setItem('autofill_mock', JSON.stringify(dataToSave));
      showStatus('💾 Đã lưu thông tin thành công (Local)!', true);
    }
  });

  // 3. Trigger autofill in the active tab
  btnTrigger.addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) return;
        const activeTab = tabs[0];
        
        // Send a message to content script
        chrome.tabs.sendMessage(activeTab.id, { action: 'TRIGGER_AUTOFILL' }, (response) => {
          if (chrome.runtime.lastError) {
            showStatus('❌ Vui lòng F5 làm mới trang web để tải extension.', false);
            console.error(chrome.runtime.lastError);
          } else if (response && response.success) {
            showStatus(`🚀 Đã điền xong ${response.filledCount} trường!`, true);
          } else {
            showStatus('⚠️ Không tìm thấy ô nhập thông tin tương thích.', false);
          }
        });
      });
    } else {
      showStatus('⚠️ Tính năng chỉ hoạt động khi chạy dạng Chrome Extension.', false);
    }
  });

  function showStatus(text, isSuccess) {
    statusMsg.textContent = text;
    statusMsg.className = isSuccess ? 'success' : '';
    
    // Reset status back to default description after 3s
    setTimeout(() => {
      statusMsg.textContent = 'Thông tin đã lưu sẽ được mã hóa cục bộ.';
      statusMsg.className = '';
    }, 3000);
  }
});
