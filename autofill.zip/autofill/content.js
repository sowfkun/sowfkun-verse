(() => {
  // 1. Regex patterns for heuristic matching (expanded for Viet/Eng and edge cases)
  const rules = {
    fullname: {
      regex: /(fullname|full_name|ho.*ten|hoten|ho_ten|name|first.*name|last.*name|user.*name|ten.*khach.*hang|chu.*tai.*khoan|chu_tai_khoan|recipient|nguoi.*nhan|owner|txt_owner|ten.*cua.*ban|ten_cua_ban|your.*name)/i,
      exclude: /(doanh_nghiep|doanh.*nghiep|cong.*ty|company|business|brand|nhan_hieu|bank|ngan.*hang|account|card|password|mat.*khau|role)/i,
      priority: 1
    },
    phone: {
      regex: /(phone|tel|sdt|dienthoai|dien_thoai|mobile|telephone|di_dong|contact_number|sdt_lien_he|sdt_di_dong)/i,
      priority: 2
    },
    email: {
      regex: /(email|mail|e-mail|dia_chi_email|thu_dien_tu|txt_email|txt_mail)/i,
      priority: 2.5
    },
    identity: {
      regex: /(cccd|cmnd|identity|national.*id|id.*card|passport|so.*ho.*chieu|cancuoc|so.*cmnd|giay.*to.*tuy.*than|card_no|id_number|id_card|txt_id)/i,
      priority: 3
    },
    address: {
      regex: /(address|diachi|dia_chi|street|city|location|tinh.*thanh|quan.*huyen|phuong.*xa|noi.*o|thuong.*tru|home.*addr|ship.*addr|delivery.*addr|dia_diem_nhan)/i,
      priority: 4
    },
    yob: {
      regex: /(dob|birth|yob|ngaysinh|ngay_sinh|namsinh|nam_sinh|birthday|date.*birth|year.*birth|txt_dob|txt_yob)/i,
      priority: 5
    }
  };

  // 2. Main heuristic scorer
  function matchInputs(savedData) {
    const inputs = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]), textarea'));
    const matchedFields = []; // Array of { element, fieldKey, value }

    inputs.forEach(input => {
      // Skip if input is not visible or disabled
      if (input.offsetWidth === 0 || input.offsetHeight === 0 || input.disabled || input.readOnly) {
        return;
      }

      let bestField = null;
      let highestScore = 0;

      // Extract context text from target attributes
      const attributes = [
        { name: 'id', weight: 45 },
        { name: 'name', weight: 50 },
        { name: 'placeholder', weight: 40 },
        { name: 'class', weight: 15 },
        { name: 'autocomplete', weight: 30 },
        { name: 'aria-label', weight: 30 }
      ];

      Object.keys(rules).forEach(fieldKey => {
        if (!savedData[fieldKey]) return; // Skip if no saved value for this key
        const config = rules[fieldKey];
        let score = 0;

        // A. Score based on input attributes
        attributes.forEach(attr => {
          const val = input.getAttribute(attr.name);
          if (val && config.regex.test(val)) {
            score += attr.weight;
          }
        });

        // B. Score based on associated <label>
        let labelText = '';
        if (input.id) {
          const label = document.querySelector(`label[for="${input.id}"]`);
          if (label) {
            labelText = label.innerText;
          }
        }
        // If label not found by for-id, check parent label
        if (!labelText) {
          const parentLabel = input.closest('label');
          if (parentLabel) {
            labelText = parentLabel.innerText;
          }
        }
        if (labelText && config.regex.test(labelText)) {
          score += 45;
        }

        // C. Advanced Proximity Search (sibling & parent-sibling text nodes)
        // Check immediate sibling text (e.g., span or small label next to input)
        let prevElement = input.previousElementSibling;
        let siblingText = '';
        if (prevElement) {
          siblingText = prevElement.textContent || prevElement.innerText;
        }
        if (siblingText && config.regex.test(siblingText)) {
          score += 35;
        }

        // Check parent's previous sibling text (crucial for modern SPA nested divs and table layout cells)
        let parentPrev = input.parentElement?.previousElementSibling;
        let parentPrevText = '';
        if (parentPrev) {
          parentPrevText = parentPrev.textContent || parentPrev.innerText;
          if (parentPrevText && config.regex.test(parentPrevText)) {
            score += 40;
          }
        }

        // Check nearest general container text (e.g., .form-group or closest td/div)
        let containerText = '';
        const closestContainer = input.closest('.form-group, tr, td, .field-wrapper');
        if (closestContainer) {
          containerText = closestContainer.innerText || '';
          // Avoid matching child input values, focus on label content
          if (containerText && config.regex.test(containerText)) {
            score += 25;
          }
        }

        // D. Recursive Ancestor text search (up to 3 levels)
        let ancestorText = '';
        let currentParent = input.parentElement;
        let depth = 0;
        while (currentParent && depth < 3) {
          Array.from(currentParent.childNodes).forEach(node => {
            if (node.nodeType === Node.TEXT_NODE) {
              ancestorText += ' ' + node.textContent;
            } else if (node.nodeType === Node.ELEMENT_NODE && !['INPUT', 'TEXTAREA', 'SELECT'].includes(node.tagName)) {
              ancestorText += ' ' + (node.textContent || '');
            }
          });
          currentParent = currentParent.parentElement;
          depth++;
        }
        if (ancestorText && config.regex.test(ancestorText)) {
          score += 30;
        }

        // E. HTML5 type bonuses
        if (fieldKey === 'phone' && input.type === 'tel') {
          score += 50;
        }
        if (fieldKey === 'yob' && input.type === 'date') {
          score += 50;
        }
        if (fieldKey === 'email' && input.type === 'email') {
          score += 50;
        }

        // F. Apply Exclusions (very important to avoid mismatching fields like Business Name vs User Name)
        if (config.exclude && score > 0) {
          let isExcluded = false;
          
          // Check attributes
          attributes.forEach(attr => {
            const val = input.getAttribute(attr.name);
            if (val && config.exclude.test(val)) isExcluded = true;
          });

          // Check all gathered text contexts
          if (labelText && config.exclude.test(labelText)) isExcluded = true;
          if (siblingText && config.exclude.test(siblingText)) isExcluded = true;
          if (parentPrevText && config.exclude.test(parentPrevText)) isExcluded = true;
          if (containerText && config.exclude.test(containerText)) isExcluded = true;
          if (ancestorText && config.exclude.test(ancestorText)) isExcluded = true;

          if (isExcluded) {
            score = 0; // Revoke match
          }
        }

        // Keep the field with highest heuristic match score
        if (score > highestScore) {
          highestScore = score;
          bestField = fieldKey;
        }
      });

      // Threshold: A match is valid if the score exceeds a threshold (e.g., 20)
      if (bestField && highestScore > 20) {
        matchedFields.push({
          element: input,
          fieldKey: bestField,
          value: savedData[bestField],
          score: highestScore
        });
      }
    });

    return matchedFields;
  }


  // 3. Fill values and trigger frameworks synthetic inputs (React, Vue compatibility)
  function fillValue(element, value) {
    if (!element) return;

    // React 15/16+ input values tracker compatibility bypass
    const valueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    const textareaValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    const prototypeValueSetter = element.tagName === 'TEXTAREA' ? textareaValueSetter : valueSetter;

    if (prototypeValueSetter && prototypeValueSetter !== value) {
      prototypeValueSetter.call(element, value);
    } else {
      element.value = value;
    }

    // Trigger basic events
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // 4. Core Executor
  function executeAutofill(savedData) {
    const matches = matchInputs(savedData);
    let filledCount = 0;

    matches.forEach(match => {
      let val = match.value;
      // Smart conversion: if input expects a date format but user only provided a year
      if (match.fieldKey === 'yob') {
        if (match.element.type === 'date' && /^\d{4}$/.test(val)) {
          val = `${val}-01-01`;
        } else if (match.element.placeholder && /(dd|mm|yyyy|ngày|tháng|năm)/i.test(match.element.placeholder) && /^\d{4}$/.test(val)) {
          val = `01/01/${val}`;
        }
      }
      fillValue(match.element, val);
      
      // Visual feedback: brief highlight animation
      const originalBorder = match.element.style.borderColor;
      const originalBoxShadow = match.element.style.boxShadow;
      
      match.element.style.borderColor = '#10b981';
      match.element.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.25)';
      match.element.style.transition = 'all 0.3s ease';

      setTimeout(() => {
        match.element.style.borderColor = originalBorder;
        match.element.style.boxShadow = originalBoxShadow;
      }, 1500);

      filledCount++;
    });

    return filledCount;
  }

  // 5. Message Listener
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'TRIGGER_AUTOFILL') {
        chrome.storage.local.get(Object.keys(rules), (data) => {
          const count = executeAutofill(data);
          sendResponse({ success: count > 0, filledCount: count });
        });
        return true; // Keep message channel open for async response
      }
    });
  }

  // 6. Visual Enhancement: Smart Floating Trigger Bubble
  // Show a tiny premium widget when form inputs are present, prompting the user they can autofill
  function checkAndCreateFloatingBubble() {
    // Avoid double creation
    if (document.getElementById('smart-autofill-floater')) return;

    // Check if there are any forms/inputs on screen
    const visibleInputs = Array.from(document.querySelectorAll('input:not([type="hidden"]), textarea'))
      .filter(input => input.offsetWidth > 0 && input.offsetHeight > 0);

    if (visibleInputs.length === 0) return;

    // Fetch saved data
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(Object.keys(rules), (data) => {
        // Only show if user has configured some data
        const hasData = Object.values(data).some(val => val && val.trim().length > 0);
        if (hasData) {
          createFloater(data);
        }
      });
    }
  }

  function createFloater(savedData) {
    const floater = document.createElement('div');
    floater.id = 'smart-autofill-floater';
    
    // Style floating bubble (vibrant, modern design)
    floater.style.position = 'fixed';
    floater.style.bottom = '24px';
    floater.style.right = '24px';
    floater.style.zIndex = '999999';
    floater.style.display = 'flex';
    floater.style.alignItems = 'center';
    floater.style.gap = '8px';
    floater.style.background = 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)';
    floater.style.color = '#ffffff';
    floater.style.padding = '10px 16px';
    floater.style.borderRadius = '30px';
    floater.style.boxShadow = '0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 4px 10px -3px rgba(0, 0, 0, 0.2)';
    floater.style.fontFamily = "'Plus Jakarta Sans', system-ui, sans-serif";
    floater.style.fontSize = '13px';
    floater.style.fontWeight = '600';
    floater.style.cursor = 'pointer';
    floater.style.userSelect = 'none';
    floater.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';

    floater.innerHTML = `
      <span style="font-size: 16px; animation: pulse 2s infinite;">⚡</span>
      <span>Điền nhanh form</span>
    `;

    // Add pulse animation keyframe
    const styleSheet = document.createElement('style');
    styleSheet.type = 'text/css';
    styleSheet.innerText = `
      @keyframes pulse {
        0% { transform: scale(1); filter: drop-shadow(0 0 0 rgba(255,255,255,0.4)); }
        70% { transform: scale(1.1); filter: drop-shadow(0 0 8px rgba(255,255,255,0)); }
        100% { transform: scale(1); }
      }
      #smart-autofill-floater:hover {
        transform: translateY(-2px) scale(1.03);
        box-shadow: 0 12px 30px -5px rgba(99, 102, 241, 0.6), 0 6px 12px -3px rgba(0, 0, 0, 0.3);
      }
      #smart-autofill-floater:active {
        transform: translateY(1px) scale(0.98);
      }
    `;
    document.head.appendChild(styleSheet);

    floater.addEventListener('click', () => {
      const count = executeAutofill(savedData);
      if (count > 0) {
        floater.innerHTML = `<span>✓</span> <span>Đã điền ${count} ô</span>`;
        floater.style.background = '#10b981';
        floater.style.boxShadow = '0 10px 25px -5px rgba(16, 185, 129, 0.5)';
        
        setTimeout(() => {
          floater.innerHTML = `<span>⚡</span> <span>Điền nhanh form</span>`;
          floater.style.background = 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)';
          floater.style.boxShadow = '0 10px 25px -5px rgba(99, 102, 241, 0.5)';
        }, 2000);
      } else {
        floater.innerHTML = `<span>⚠️</span> <span>Không tìm thấy ô khớp</span>`;
        floater.style.background = '#f59e0b';
        floater.style.boxShadow = '0 10px 25px -5px rgba(245, 158, 11, 0.5)';
        
        setTimeout(() => {
          floater.innerHTML = `<span>⚡</span> <span>Điền nhanh form</span>`;
          floater.style.background = 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)';
          floater.style.boxShadow = '0 10px 25px -5px rgba(99, 102, 241, 0.5)';
        }, 2000);
      }
    });

    document.body.appendChild(floater);
  }

  // Run initial scan and set listener
  setTimeout(checkAndCreateFloatingBubble, 1000);

  // Debounced observer to avoid CPU overhead on rapid DOM updates in SPAs
  let timeoutId = null;
  const observer = new MutationObserver(() => {
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = setTimeout(checkAndCreateFloatingBubble, 300);
  });
  observer.observe(document.body, { childList: true, subtree: true });

})();
